tinyMCE.addI18n('si.advhr_dlg',{
width:"Width",
size:"Height",
noshade:"No shadow"
});