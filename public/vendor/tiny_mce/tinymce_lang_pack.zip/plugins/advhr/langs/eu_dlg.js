tinyMCE.addI18n('eu.advhr_dlg',{
width:"Zabalera",
size:"Altuera",
noshade:"Itzalik gabe"
});