tinyMCE.addI18n('es.advhr_dlg',{
width:"Ancho",
size:"Alto",
noshade:"Sin sombra"
});