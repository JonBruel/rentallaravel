tinyMCE.addI18n('he.advhr_dlg',{
width:"\u05E8\u05D5\u05D7\u05D1",
size:"\u05D2\u05D5\u05D1\u05D4",
noshade:"\u05DC\u05DC\u05D0 \u05E6\u05DC"
});