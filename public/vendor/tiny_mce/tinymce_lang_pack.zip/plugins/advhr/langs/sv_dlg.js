tinyMCE.addI18n('sv.advhr_dlg',{
width:"Bredd",
size:"H\u00F6jd",
noshade:"Ingen skugga"
});