tinyMCE.addI18n('is.advhr_dlg',{
width:"Breidd",
size:"H\u00E6\u00F0",
noshade:"Enginn skuggi"
});